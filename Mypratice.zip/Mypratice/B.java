class B{
  public static void main(String[] args){
	int count = 0;
	while(count < 50){
	System.out.println("" + count);
	count = count + 2;
	}
  }
}