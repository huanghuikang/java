class A{
  public static void main(String[] args){
	int count = 0;
	while(count < 5){
	System.out.println("Hello World!");
	count++;
	}
  }
}