class Untitled1 
{
	public static void main(String[] args) 
	{
		int a;
		int sum=0;
		for(a=1;a<=100;a++){sum+=a;}
		System.out.println("1+2+3+4+....+100="+sum);
	}
}
