package com.digitalweb.dao;

public interface AdminDao {
	public int verify(String userName,String password);
}
