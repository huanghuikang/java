﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Model;
using DAL;

namespace DAL
{
    public class MemberServer
    {
        public SqlDataReader LoginByUserNameAndPassword(nenber objnenber)
        {
            string sql = "select * from Number where LoginName=@LoginName and LoginPwd=@LoginPwd";
            SqlParameter[] param = new SqlParameter[] 
           { 
               new SqlParameter("@LoginName", objnenber.LoginName),
               new SqlParameter ("@LoginPwd",objnenber .LoginPwd ),
           };
            return SqlDbHelper.ExecuteReader(sql, CommandType.Text, param);

        }
        public int UserRegion(nenber objnenber)
        {
            string sql = "insert into Number( LoginName, LoginPwd, Sex, Birth,Phone, Address)";
            sql += " values(@LoginName,@LoginPwd,@Sex,@Birth,@Phone,@Address)";
            SqlParameter[] param = new SqlParameter[]
           {
               new SqlParameter ("@LoginName",objnenber.LoginName ),
               new SqlParameter ("@LoginPwd",objnenber .LoginPwd ),
               new SqlParameter ("@Sex",objnenber .Sex),
               new SqlParameter ("@Birth",objnenber .Birth ),
               new SqlParameter ("@Phone",objnenber.Phone ),
               new SqlParameter ("@Address",objnenber.Address ),

           };
            return SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text, param);
        }
        public int UpdateNew(member objNew)
        {
            string sql = "insert into News(NewTitle,NewContent,NewAddTime,NewAddAuthor)";
            sql += "values(@NewTitle,@NewContent,@NewAddTime,@NewAddAuthor)";
            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@NewTitle",objNew.NewTitle),
                new SqlParameter("@NewContent",objNew.NewContent),
                new SqlParameter("@NewAddTime",objNew.NewAddTime),
                new SqlParameter("@NewAddAuthor",objNew.NewAddAuthor),
            };
            return SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text, param);
        }
    }
}
