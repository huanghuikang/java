﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace News.Views
{
    public partial class newList : System.Web.UI.Page
    {
        string sql;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //string sql = "select NewId, NewTitle, convert(char(10), NewAddTime,120) as NewAddTime from News order by NewAddTime";
                //SqlParameter[] param = null;
                //Repeater1.DataSource = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, param);
                //Repeater1.DataBind();
                sql = "select count(*) from News";
                SqlParameter[] param = null;
                AspNetPager1.RecordCount = int.Parse(SqlDbHelper.ExecuteScalar(sql, CommandType.Text, param).ToString());
                RepeaterDataBind();

            }
        }
        private void RepeaterDataBind()
        {
            sql = "select NewId, NewTitle, convert(char(10), NewAddTime,120) as NewAddTime from News order by NewAddTime DESC";
            SqlParameter[] param = null;
            int pageStart = AspNetPager1.PageSize * (AspNetPager1.CurrentPageIndex - 1);
            int pageSize = AspNetPager1.PageSize;
            Repeater1.DataSource = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, param, pageStart, pageSize);
            Repeater1.DataBind();
        }

        protected void AspNetPager1_PageChanging(object src, Wuqi.Webdiyer.PageChangingEventArgs e)
        {
            AspNetPager1.CurrentPageIndex = e.NewPageIndex;
            RepeaterDataBind();
        }


    }
}