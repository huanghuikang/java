﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Model;
using BLL;

namespace News.Views
{
    public partial class Login : System.Web.UI.Page
    {
        MemberManager objMemberManager=new MemberManager();
        nenber objnenber = new nenber();

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            objnenber.LoginName = txtUsername.Text;
            objnenber.LoginPwd = txtPassword.Text;
            SqlDataReader dr = objMemberManager.UserNameAndPassword(objnenber);
            if (dr.Read())
            {
                Response.Redirect("newManage.aspx");
                //Response.Write("<script>alert('" + txtUsername.Text.Trim() + "用户登录成功')</script>");
                dr.Close();
            }
            else
            {
                Response.Write("<script>alert('用户名或密码错误')</script>");
                dr.Close();
            }
        }

        protected void btnReg_Click(object sender, EventArgs e)
        {
            Response.Redirect("reg.aspx");
        }
    }
}