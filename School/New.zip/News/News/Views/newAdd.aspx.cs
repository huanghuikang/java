﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Model;
using DAL;
using BLL;

namespace News.Views
{
    public partial class newAdd : System.Web.UI.Page
    {
        member objNew = new member();
        MemberManager objMemberManager = new MemberManager();
        MemberServer objMemberServer = new MemberServer();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            txtAddTime.Text = DateTime.Now.ToString();
            objNew.NewTitle = txtNewTitle.Text.Trim();
            objNew.NewAddAuthor = txtAddAuthor.Text.Trim();
            objNew.NewAddTime = DateTime.Now;
            objNew.NewContent = txtNewContent.Text.Trim();
            int i = objMemberServer.UpdateNew(objNew);
            if (i == 1)
            {
                Response.Write("<script>alert('新闻发布成功!')</script>");
            }
            else
            {
                Response.Write("<script>alert('新闻发布失败！请重试或联系管理员。')</script>");
            }

        }

        protected void txtNewContent_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {

        }
    }
}