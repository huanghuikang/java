﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using DAL;
using Model;

namespace News.Views
{
    public partial class newDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int newId;
            string sql;
            if (!IsPostBack)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["id"]))
                {
                    newId = int.Parse(Request.QueryString["id"]);
                    sql = "select * from News where NewId=" + newId;
                    SqlParameter[] param = null;
                    SqlDataReader dr = SqlDbHelper.ExecuteReader(sql, CommandType.Text, param);
                    if (dr.Read())
                    {
                        lblNewTitle.Text = dr["NewTitle"].ToString();
                        lblNewAddAuthor.Text = dr["NewAddAuthor"].ToString();
                        lblNewAddtime.Text = dr["NewAddtime"].ToString();
                        lblNewContent.Text = dr["NewContent"].ToString();
                    }

                }
            }
        }
    }
}