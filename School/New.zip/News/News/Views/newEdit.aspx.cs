﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using DAL;
using Model;

namespace News.Views
{
    public partial class newEdit : System.Web.UI.Page
    {
        member objNew = new member();
        MemberServer objMemberServer = new MemberServer();
        string sql;
        protected void Page_Load(object sender, EventArgs e)
        {
            objNew.NewId = Convert.ToInt32(Request.QueryString["NewId"]);
            if (!IsPostBack)
            {
                sql = "select * from News";
                SqlParameter[] param = null;
                SqlDataReader dr = SqlDbHelper.ExecuteReader(sql, CommandType.Text, param);
                if (dr.Read())
                {
                    objNew.NewAddAuthor = txtAddAuthor.Text.Trim();
                    objNew.NewTitle = txtNewTitle.Text.Trim();
                    objNew.NewAddTime = DateTime.Now;
                    objNew.NewContent = txtNewContent.Text.Trim();

                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            objNew.NewAddAuthor = txtAddAuthor.Text.Trim();
            objNew.NewTitle = txtNewTitle.Text.Trim();
            objNew.NewAddTime = DateTime.Now;
            objNew.NewContent = txtNewContent.Text.Trim();
            sql = "update News set NewAddAuthor=@NewAddAuthor, NewTitle=@NewTitle,NewAddTime=@NewAddTime,NewContent=@NewContent where NewId=@NewId";
            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@NewAddAuthor",objNew.NewAddAuthor),
                new SqlParameter("@NewTitle",objNew.NewTitle),
                new SqlParameter("@NewAddTime",objNew.NewAddTime),
                new SqlParameter("@NewContent",objNew.NewContent),
                new SqlParameter("@NewId",objNew.NewId),
            };
            int i = SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text, param);
            if (i == 1)
            {
                Response.Write("<script>alert('新闻修改成功！');</script>");
            }
            else
            {
                Response.Write("<script>alert('新闻修改失败！请重试或联系管理员。');</script>");
            }

        }

        protected void txtNewContent_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {

            txtNewTitle.Text = string.Empty;
            txtAddAuthor.Text = string.Empty;
            txtAddTime.Text = string.Empty;
            txtNewContent.Text = string.Empty;
        }
    }
}