﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using DAL;
using Model;

namespace News.Views
{
    public partial class newManage : System.Web.UI.Page
    {
        member objNew = new member();
        protected void Page_Load(object sender, EventArgs e)
        {

            objNew.NewAddTime = DateTime.Now;
            string sql = "SELECT NewId, NewTitle, NewAddTime FROM News ";
            SqlParameter[] param = null;
            gvNew.DataSource = SqlDbHelper.ExecuteDataTable(sql, CommandType.Text, param);
            gvNew.DataBind();

        }

        protected void gvNew_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string sql = "delete from News where NewId='" + gvNew.DataKeys[e.RowIndex].Value.ToString() + "'";

            SqlParameter[] param = null;
            int i = SqlDbHelper.ExecuteNonQuery(sql, CommandType.Text, param);
            if (i == 1)
            {
                Response.Write("<script>alert('删除成功！');</script>");
                gvNew.DataBind();
            }
        }

        protected void gvNew_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "return")
            {
                //int rowindex = Convert.ToInt32(e.CommandArgument.ToString());
                //    gvNew.Rows[rowindex].Cells[4].Text="已完成";

            }
        }
    }
}