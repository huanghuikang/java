﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BLL;
using Model;

namespace News.Views
{
    public partial class reg : System.Web.UI.Page
    {
        nenber objnenber = new nenber();
        MemberManager objMemberManger = new MemberManager();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnReg_Click(object sender, EventArgs e)
       {
            objnenber.LoginName = txtUser.Text.Trim();
            objnenber.LoginPwd = txtPassword.Text.Trim();
            objnenber.Phone = txtCall.Text.Trim();
            objnenber.Birth = txtBirth.Text.Trim();
            objnenber.Sex = radlSex.SelectedValue;
            objnenber.Address = txtAddress.Text.Trim();
            try
            {
                int i = objMemberManger.UserRegion(objnenber);
                Response.Write("<script>alert('注册成功')</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('注册失败')</script>");
            }
            objnenber.Address = txtAddress.Text.Trim();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtUser.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtCall.Text = string.Empty;
            txtBirth.Text = string.Empty;
            txtAddress.Text = string.Empty;
            radlSex.SelectedValue = string.Empty;
        }
    }
}