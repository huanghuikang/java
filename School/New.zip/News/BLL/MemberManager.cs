﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data;
using System.Data.SqlClient;
using DAL;
using BLL;

namespace BLL
{
    public class MemberManager
    {
        public SqlDataReader UserNameAndPassword(nenber objnenber)
        {
            return objMemberServer.LoginByUserNameAndPassword(objnenber);
        }
        public int UserRegion(nenber objnenber)
        {
            return objMemberServer.UserRegion(objnenber);
        }
        MemberServer objMemberServer = new MemberServer();
        public int NewAdd(member objNew)
        {
            return objMemberServer.UpdateNew(objNew);
        }
    }
}
