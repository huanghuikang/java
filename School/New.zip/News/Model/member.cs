﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class member
    {
        public int NewId { get; set; }
        public string NewTitle { get; set; }
        public string NewContent { get; set; }
        public DateTime NewAddTime { get; set; }
        public string NewAddAuthor { get; set; }
        public int PageStart { get; set; }
        public int PageSize { get; set; }
    }
}
