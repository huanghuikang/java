﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class nenber
    {
        public int Id { set; get; }
        public string LoginName { set; get; }
        public string LoginPwd { set; get; }
        public string Sex { set; get; }
        public string Birth { set; get; }
        public string Phone { set; get; }
        public string Address { set; get; }
    }
}
